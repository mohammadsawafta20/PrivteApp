<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>طلبات المتاجر</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .centered-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fffae6;
            color: #333;
            border: 2px solid #ffcc00;
            padding: 30px 40px;
            border-radius: 12px;
            z-index: 9999;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.5s ease-in-out;
            text-align: center;
        }

        .alert-content .icon {
            font-size: 40px;
            margin-bottom: 10px;
            display: block;
            animation: pulse 1.2s infinite;
        }
        .logout-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    background-color: #19dd61;
    color: white;
    border: none;
    width:100px;
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.logout-btn:hover {
    background-color: #d7d419;
}

.logout-btn i {
    font-size: 10px;
}

        .close-btn {
            background-color: #ffcc00;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .close-btn:hover {
            background-color: #e6b800;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -60%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.15); }
            100% { transform: scale(1); }
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f4f8;
        }

        header {
            background-color: #4B0082;
            color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }

        .container {
            padding: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        th {
            background-color: #eee;
            font-weight: bold;
        }

        a.button,
        button.button {
            padding: 6px 12px;
            background-color: #4B0082;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
        }

        button.button {
            border: none;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
        }

        select, button {
            padding: 8px;
            margin-top: 10px;
            width: 80%;
        }

        .close {
            float: left;
            font-size: 20px;
            color: #999;
            cursor: pointer;
        }

        .close:hover {
            color: red;
        }
    </style>

</head>
<body>

<header>


    <div class="logo">لوحة التحكم</div>
    <nav>
        <a href="#">الرئيسية</a>
        <a href="/dashboard">الخريطة</a>
        <a href="#">المتاجر</a>
        <a href="#"></a>
    </nav>
    <div class="welcome-message">
        <i class="fas fa-user-shield"></i>
        أهلاً وسهلاً بك،
    </div>
    <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
        <?php echo csrf_field(); ?>
        <button type="submit" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            <span>تسجيل الخروج</span>
        </button>
    </form>

</header>
<div class="container" >

    <?php if(session('newRequest')): ?>
    <div id="newRequestAlert" class="centered-alert">
        <div class="alert-content">
            <span class="icon">🔔</span>
            <p><strong>تنبيه:</strong> هناك طلب جديد تم إرساله!</p>
            <button onclick="closeAlert()" class="close-btn">إغلاق</button>
        </div>
    </div>

    <audio id="notificationSound" autoplay>
        <source src="https://www.soundjay.com/buttons/sounds/beep-07.mp3" type="audio/mpeg">
    </audio>

    <script>
        window.addEventListener('DOMContentLoaded', function () {
            const sound = document.getElementById('notificationSound');
            if (sound) sound.play().catch(() => {});
        });

        function closeAlert() {
            document.getElementById('newRequestAlert')?.remove();
        }

        setTimeout(() => {
            closeAlert();
        }, 10000);
    </script>

    <?php session()->forget('newRequest'); ?>
<?php endif; ?>


    <div class="stat-box">
        <h3> عدد الطلبات المرسله </h3>
        <p><?php echo e($ordersCount); ?></p>
    </div>
    <div class="stat-box">
        <h3>عدد السائقين المتاحين</h3>
        <p><?php echo e($availableDriversCount); ?></p>
    </div>

    <h2>طلبات المتاجر</h2>

    <table>
        <tr>
            <th>المتجر</th>
            <th>التفاصيل</th>
            <th>الموقع</th>
            <th>إجراء</th>
        </tr>
        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($req->store_name); ?></td>
                <td><?php echo e($req->status); ?></td>
                <td><?php echo e($req->latitude); ?>,<?php echo e($req->longitude); ?></td>
                <td>
                    <a class="button" onclick="openModal(<?php echo e($req->id); ?>, '<?php echo e($req->store_name); ?>')">تحديد سائق</a>
                    <a href="<?php echo e(route('Addnewvender', ['request_id' => $req->id])); ?>" class="button">حفظ</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<!-- نافذة منبثقة لاختيار السائق -->
<div id="driverModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">×</span>
        <h3>اختيار سائق للمتجر: <span id="storeName"></span></h3>
        <form method="POST" action="<?php echo e(route('dashbord.assign.driver')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="vendor_id" id="storeId">
            <label for="driver_id">اختر السائق:</label><br>
            <select name="driver_id" required>
                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            <button type="submit">حفظ الطلب</button>
        </form>
    </div>
</div>

<script>
    function openModal(storeId, storeName) {
        document.getElementById('driverModal').style.display = 'block';
        document.getElementById('storeId').value = storeId;
        document.getElementById('storeName').textContent = storeName;
    }

    function closeModal() {
        document.getElementById('driverModal').style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target === document.getElementById('driverModal')) {
            closeModal();
        }
    };
</script>

</body>
</html>
<?php /**PATH C:\delivery-system\resources\views/dashbord/Adminpage.blade.php ENDPATH**/ ?>