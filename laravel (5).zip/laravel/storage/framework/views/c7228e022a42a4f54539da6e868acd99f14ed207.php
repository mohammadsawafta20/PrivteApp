<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>لوحة تتبع الطلبات</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <style>
        #map { height: 100vh; }
        #assignModal {
            display: none;
            position: fixed;
            top: 20%;
            left: 30%;
            width: 300px;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div id="map"></div>

    <div id="assignModal">
        <h4>اختر سائق لتوصيل الطلب</h4>
        <select id="driverSelect"></select><br><br>
        <button onclick="assignDriver()">تأكيد</button>
        <button onclick="closeAssignModal()">إلغاء</button>
    </div>

    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        const map = L.map('map').setView([31.9539, 35.9106], 12); // عمان، الأردن

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        let vendorMarkers = [];
        let driverMarkers = [];
        let selectedVendorId = null;

        function loadVendorsWithStatus() {
            fetch('http://localhost:8000/vendors/with-status')
                .then(res => res.json())
                .then(data => {
                    vendorMarkers.forEach(m => map.removeLayer(m));
                    vendorMarkers = [];

                    data.forEach(vendor => {
                        const lat = vendor.latitude;
                        const lng = vendor.longitude;
                        const name = vendor.user.name;
                        const phone = vendor.user.phone;
                        const isAssigned = vendor.order && vendor.order.status === 'assigned';

                        const icon = L.icon({
    iconUrl: vendor.store_request
        ? (isAssigned
            ? 'https://cdn-icons-png.flaticon.com/512/3881/3881532.png'
            : 'https://cdn-icons-gif.flaticon.com/15575/15575664.gif') // متحركة عند وجود طلب
        : 'https://cdn-icons-png.flaticon.com/512/7511/7511667.png',
    iconSize: [36, 36]
});


                        let popupHtml = `<b>${name}</b><br>📞 ${phone}<br>`;

                        if (vendor.store_request && !isAssigned) {
                            popupHtml += `<button onclick=\"openAssignModal(${vendor.id})\">📦 إسناد الطلب</button>`;
                        } else if (isAssigned) {
                            popupHtml += `<span>🚚 تم إسناد الطلب</span>`;
                        } else {
                            popupHtml += `<span>🟢 لم يرسل طلب</span>`;
                        }

                        const marker = L.marker([lat, lng], { icon: icon })
                            .addTo(map)
                            .bindPopup(popupHtml);

                        vendorMarkers.push(marker);
                    });
                });
        }

        function loadOnlineDrivers() {
            fetch('http://localhost:8000/api/drivers/online')
                .then(res => res.json())
                .then(data => {
                    driverMarkers.forEach(m => map.removeLayer(m));
                    driverMarkers = [];

                    data.forEach(driver => {
                        const lat = driver.latitude;
                        const lng = driver.longitude;
                        const name = driver.user.name;
                        const phone = driver.user.phone;
                        const isAssigned = driver.order && driver.order.status === 'assigned';

                        const icon = L.icon({
                            iconUrl: isAssigned ? 'https://cdn-icons-png.flaticon.com/512/4214/4214491.png' : 'https://cdn-icons-png.flaticon.com/512/1048/1048339.png',
                            iconSize: [36, 36]
                        });

                        const marker = L.marker([lat, lng], { icon: icon })
                            .addTo(map)
                            .bindPopup(`<b>${name}</b><br>📞 ${phone}`);

                        driverMarkers.push(marker);
                    });
                });
        }

        function openAssignModal(vendorId) {
            selectedVendorId = vendorId;
            fetch('/api/drivers/online')
                .then(res => res.json())
                .then(data => {
                    const select = document.getElementById('driverSelect');
                    select.innerHTML = '';
                    data.forEach(driver => {
                        select.innerHTML += `<option value="${driver.id}">${driver.user.name} (${driver.user.phone})</option>`;
                    });
                    document.getElementById('assignModal').style.display = 'block';
                });
        }

        function closeAssignModal() {
            document.getElementById('assignModal').style.display = 'none';
            selectedVendorId = null;
        }

        function assignDriver() {
            const driverId = document.getElementById('driverSelect').value;
            fetch('/api/orders/assign', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    vendor_id: selectedVendorId,
                    driver_id: driverId
                })
            })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                closeAssignModal();
                updateMapData();
            })
            .catch(err => {
                alert('❌ حدث خطأ أثناء الإسناد');
                console.error(err);
            });
        }

        function updateMapData() {
            loadVendorsWithStatus();
            loadOnlineDrivers();
        }

        updateMapData();
        setInterval(updateMapData, 30000);
    </script>
</body>
</html>
<?php /**PATH C:\New folder\laravel2\resources\views/dashbord/dashbord.blade.php ENDPATH**/ ?>