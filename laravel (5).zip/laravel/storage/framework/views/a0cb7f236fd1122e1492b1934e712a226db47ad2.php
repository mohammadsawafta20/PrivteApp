<!DOCTYPE html>
<html lang="ar" dir="rtl" >
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>عرض بيانات المناطق مع تعديل وحذف</title>
  <style>
    :root {
      --primary-color: #1e90ff;
      --bg-color: #f9fbff;
      --text-color: #333;
      --table-header-bg: #1e90ff;
      --table-header-color: white;
      --table-row-bg-alt: #f2f7ff;
      --btn-edit-bg: #f4b41a;
      --btn-edit-bg-hover: #d39800;
      --btn-delete-bg: #e63946;
      --btn-delete-bg-hover: #b52a33;
      --font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body {
      margin: 0;
      padding: 20px;
      font-family: var(--font-family);
      background-color: var(--bg-color);
      color: var(--text-color);
      display: flex;
      justify-content: center;
      align-items: flex-start;
      min-height: 100vh;
    }
    .table-container {
      background: white;
      border-radius: 12px;
      padding: 25px 20px;
      box-shadow: 0 4px 12px rgb(0 0 0 / 0.1);
      width: 100%;
      max-width: 700px;
    }
    h2 {
      margin-top: 0;
      margin-bottom: 20px;
      text-align: center;
      color: var(--primary-color);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      direction: rtl;
      user-select: none;
      table-layout: fixed;
    }
    thead {
      background-color: var(--table-header-bg);
      color: var(--table-header-color);
    }
    th, td {
      padding: 12px 10px;
      text-align: center;
      border: 1px solid #ccc;
      word-wrap: break-word;
    }
    tbody tr:nth-child(even) {
      background-color: var(--table-row-bg-alt);
    }
    tbody tr:hover {
      background-color: #d6eaff;
    }
    button.action-btn {
      border: none;
      border-radius: 6px;
      padding: 6px 12px;
      font-size: 0.9rem;
      font-weight: 600;
      cursor: pointer;
      color: white;
      user-select: none;
      margin: 0 5px;
      transition: background-color 0.3s ease;
    }
    button.edit-btn {
      background-color: var(--btn-edit-bg);
    }
    button.edit-btn:hover {
      background-color: var(--btn-edit-bg-hover);
    }
    button.delete-btn {
      background-color: var(--btn-delete-bg);
    }
    button.delete-btn:hover {
      background-color: var(--btn-delete-bg-hover);
    }
    input.edit-input {
      width: 90%;
      padding: 6px 8px;
      font-size: 1rem;
      border: 2px solid var(--btn-edit-bg);
      border-radius: 6px;
      box-sizing: border-box;
      text-align: center;
    }
    /* Responsive font size */
    @media (max-width: 600px) {
      th, td {
        font-size: 0.9rem;
        padding: 10px 8px;
      }
      .table-container {
        max-width: 100%;
        padding: 20px 15px;
      }
      button.action-btn {
        padding: 5px 10px;
        font-size: 0.85rem;
        margin: 0 3px;
      }
    }
  </style>
</head>
<body>
  <div class="table-container">
    <h2>بيانات المناطق</h2>
    <table aria-label="جدول بيانات المناطق">
      <thead>
        <tr>
          <th>اسم المنطقة</th>
          <th>السعر</th>
          <th>إجراء</th>
        </tr>
      </thead>
      <tbody id="regionsTableBody">
        <!-- ستضاف بيانات الصفوف هنا -->
      </tbody>
    </table>
  </div>

  <script>
    const tbody = document.getElementById('regionsTableBody');

    // دالة تحديث عرض الجدول بالبيانات من API أو مصدر خارجي
    function renderTable(data) {
      tbody.innerHTML = "";
      if (!data || data.length === 0) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.setAttribute("colspan", "3");
        td.textContent = "لا توجد بيانات لعرضها";
        td.style.fontStyle = "italic";
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
      }

      data.forEach((item, index) => {
        const tr = document.createElement("tr");

        const tdName = document.createElement("td");
        tdName.textContent = item.name || "";
        tr.appendChild(tdName);

        const tdPrice = document.createElement("td");
        tdPrice.textContent = (item.price !== undefined && item.price !== null)
          ? Number(item.price).toFixed(2) + " ر.س"
          : "";
        tr.appendChild(tdPrice);

        const tdActions = document.createElement("td");

        const editBtn = document.createElement("button");
        editBtn.textContent = "تعديل";
        editBtn.classList.add("action-btn", "edit-btn");
        editBtn.setAttribute("aria-label", `تعديل المنطقة ${item.name || ""}`);

        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "حذف";
        deleteBtn.classList.add("action-btn", "delete-btn");
        deleteBtn.setAttribute("aria-label", `حذف المنطقة ${item.name || ""}`);

        tdActions.appendChild(editBtn);
        tdActions.appendChild(deleteBtn);
        tr.appendChild(tdActions);

        /* الوظائف الخاصة بالتعديل والحذف يجب ربطها خارجياً حسب الحاجة */

        tbody.appendChild(tr);
      });
    }

    // مثال: جلب البيانات من API - ضع رابط API الخاص بك هنا
    /*
    fetch('https://api.example.com/regions')
      .then(response => response.json())
      .then(data => {
        renderTable(data);
      })
      .catch(err => {
        console.error('خطأ في جلب البيانات:', err);
        renderTable([]);
      });
    */

    // لعرض جدول فارغ مبدئياً
    renderTable([]);
  </script>
</body>
</html>

<?php /**PATH /home/u678210090/domains/privateapp.online/laravel/resources/views/ShowAreas.blade.php ENDPATH**/ ?>