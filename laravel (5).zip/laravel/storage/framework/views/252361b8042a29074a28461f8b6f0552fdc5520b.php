<style>
    body {
        background: #f0f4f8;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 960px;
        margin: 40px auto;
        background: #fff;
        box-shadow: 0 4px 12px rgb(0 0 0 / 0.1);
        border-radius: 8px;
        padding: 30px;
    }
    h2 {
        text-align: center;
        color: #2c3e50;
        margin-bottom: 25px;
        font-weight: 700;
        letter-spacing: 1px;
    }
    nav.navbar {
        background: #34495e;
        padding: 12px 20px;
        border-radius: 8px;
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #ecf0f1;
    }
    nav.navbar a {
        color: #ecf0f1;
        margin-left: 15px;
        text-decoration: none;
        font-weight: 600;
        transition: color 0.3s ease;
    }
    nav.navbar a:hover {
        color: #1abc9c;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 15px;
    }
    thead {
        background: #1abc9c;
        color: white;
        font-weight: 600;
    }
    thead th {
        padding: 12px 15px;
        text-align: center;
    }
    tbody tr {
        border-bottom: 1px solid #ddd;
        transition: background 0.3s ease;
    }
    tbody tr:hover {
        background: #eaf7f6;
    }
    tbody td {
        padding: 12px 15px;
        text-align: center;
        color: #555;
    }
    .empty-row {
        text-align: center;
        padding: 20px;
        color: #999;
        font-style: italic;
    }
    .green-row {
    background-color: #d4edda; /* أخضر فاتح */
    color: #08f43f; /* نص أخضر غامق */
}

.red-row {
    background-color: #f8d7da; /* أحمر فاتح */
    color: #f30921; /* نص أحمر غامق */
}

.empty-row {
    text-align: center;
    font-style: italic;
    color: #888;
}


</style>

    <nav class="navbar">

        <div class="navbar-brand">الطلبات </div>
        <div>
            <a href="">الرئيسية</a>
            <a href="">الطلبات المستلمة</a>
            <a href="/requests" style="color:#e74c3c;">تسجيل الخروج</a>
        </div>
    </nav>

    <h2>الطلبات  التي وصلت اليوم</h2>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>السائق</th>
                <th>المتجر</th>
                <th>الحالة</th>
                <th>المبلغ الكلي</th>
                <th>تاريخ الطلب</th>
                <th>اجراء</th>
            </tr>
        </thead>
        <tbody>



            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php
            $rowClass = '';
            if ($order->status == 'completed') {
                $rowClass = 'green-row';
            } elseif ($order->status == 'cancelled') {
                $rowClass = 'red-row';
            }
               ?>

            <tr class="<?php echo e($rowClass); ?>">
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->driver->user->name ?? 'غير محدد'); ?></td>  <!-- اسم السائق -->
                <td><?php echo e($order->vendor->store_name ?? 'غير محدد'); ?></td>  <!-- اسم المتجر -->
                <td><?php echo e($order->status); ?>





                </td>


                <td><?php echo e(number_format($order->total_amount, 2)); ?> دينار</td>
                <td><?php echo e($order->created_at); ?></td>
                <td>

                    <form method="POST" action="<?php echo e(route('driver.orders.updateStatus', $order->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <select name="status" onchange="this.form.submit()">
                            <?php
                                $statuses = ['assigned', 'pending', 'in_progress', 'completed', 'cancelled'];
                            ?>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>" <?php if($order->status === $status): ?> selected <?php endif; ?>>
                                    <?php echo e(ucfirst(str_replace('_', ' ', $status))); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </form>


                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="empty-row">لا توجد طلبات حالياً</td>
            </tr>

            <?php endif; ?>
        </tbody>
    </table>
</div>



  <tr>
                            <td><?php echo e($order->id); ?></td>

<?php /**PATH /home/u678210090/domains/privateapp.online/laravel/resources/views/Orderpage.blade.php ENDPATH**/ ?>