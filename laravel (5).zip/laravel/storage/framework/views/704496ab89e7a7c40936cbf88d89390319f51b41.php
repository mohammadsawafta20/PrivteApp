

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>📍 قائمة المناطق الرئيسية</h2>
    <a href="<?php echo e(route('areas.create')); ?>" class="btn btn-success mb-3">➕ إضافة منطقة</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>اسم المنطقة</th>
                <th>الافرع</th>
                <th>تحكم</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($area->name); ?></td>
                    <td>
                        <ul>
                       <?php $__currentLoopData = $area->subareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        🏷️ <?php echo e($sub->name); ?>

        <?php if($sub->delivery_price): ?>
            - 💰 <?php echo e(number_format($sub->delivery_price, 2)); ?> د.أ
        <?php endif; ?>

        <a href="<?php echo e(route('subareas.edit', $sub->id)); ?>" class="text-primary ms-2">✏️</a>

        <form action="<?php echo e(route('subareas.destroy', $sub->id)); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button onclick="return confirm('حذف الفرع؟')" class="btn btn-sm btn-link text-danger">🗑️</button>
        </form>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <a href="<?php echo e(route('subareas.create', ['area_id' => $area->id])); ?>" class="btn btn-sm btn-outline-secondary">➕ فرع</a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('areas.edit', $area->id)); ?>" class="btn btn-sm btn-primary">✏️ تعديل</a>
                        <form action="<?php echo e(route('areas.destroy', $area->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('هل أنت متأكد؟')" class="btn btn-sm btn-danger">🗑️ حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/ShowAreas.blade.php ENDPATH**/ ?>