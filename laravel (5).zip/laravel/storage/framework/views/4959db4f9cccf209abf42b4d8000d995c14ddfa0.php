

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('areas.store')); ?>">
    <?php echo csrf_field(); ?>
    <label>اسم المنطقة:</label>
    <input type="text" name="name" class="form-control" required>
    <button type="submit" class="btn btn-success mt-2">حفظ</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/AddAreas.blade.php ENDPATH**/ ?>