<!DOCTYPE html>
<html lang="ar">
    <head>
        <meta charset="UTF-8">
        <title>متجر توصيل الطلبات </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Leaflet CSS -->
        <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            header {
                background-color: #4B0082	;
                color: white;
                padding: 15px 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
            }

            .logo {
                font-size: 20px;
                font-weight: bold;
            }

            nav a {
                color: white;
                text-decoration: none;
                margin: 0 10px;
                font-weight: 500;
            }

            nav a:hover {
                text-decoration: underline;
            }

            .counters {
                margin-top: 10px;
                font-size: 14px;
            }

            h1 {
                text-align: center;
                margin: 20px 0;
            }

            #order-map {
                width: 100%;
                height: 600px;
            }

            #loading {
                position: fixed;
                top: 80px;
                left: 50%;
                transform: translateX(-50%);
                background-color: #ffffff;
                border: 1px solid #ccc;
                padding: 10px 20px;
                font-weight: bold;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .stats {
                display: flex;
                gap: 15px;
                font-size: 14px;
            }

            .stats span {
                background: rgba(255, 255, 255, 0.2);
                padding: 5px 10px;
                border-radius: 10px;
            }
        </style>
    </head>
    <body>

        <!-- ✅ الهيدر مع عدادات -->
        <header>
            <div class="logo">موقع لتوصيل الطلبات</div>
            <nav>
                <a href="#">الطلبات</a>
                <a href="#">المتاجر</a>
                <a href="#">المستخدمين</a>
                <a href="/requests">حروج</a>
            </nav>
            <div class="stats">
                <span id="driver-count">السائقين: 0</span>
                <span id="vendor-count">المتاجر: 0</span>
            </div>
        </header>

<body>


    <div id="loading">🔄 جاري تحميل الخريطة...</div>

    <div id="order-map" style="width: 100%; height: 600px;"></div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        const loadingDiv = document.getElementById('loading');
        const driverCount = document.getElementById('driver-count');
        const vendorCount = document.getElementById('vendor-count');

        fetch('http://localhost:8000/api/map/data')
            .then(response => response.json())
            .then(data => {
                const drivers = data.drivers || [];
                const vendors = data.vendors || [];

                driverCount.textContent = `السائقين: ${drivers.length}`;
                vendorCount.textContent = `المتاجر: ${vendors.length}`;

                const map = L.map('order-map').setView([31.963158, 35.930359], 13);

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors'
                }).addTo(map);

                // عرض السائقين
                drivers.forEach(driver => {
                    let lat = parseFloat(driver.latitude) || 0;
                    let lng = parseFloat(driver.longitude) || 0;


                    let statusText = driver.status === 'available' ? 'متاح' : 'غير متاح';

                    let driverIcon = L.icon({
                        iconUrl: driver.status === 'available'
                            ? 'https://cdn-icons-png.freepik.com/256/2401/2401174.png?ga=GA1.1.1293284205.1746954550&semt=ais_hybrid'
                            : 'https://cdn-icons-png.flaticon.com/128/7730/7730531.png',
                        iconSize: [50, 50],
                        iconAnchor: [15, 30],
                        popupAnchor: [0, -30]
                    });

                    L.marker([lat, lng], { icon: driverIcon })
                        .addTo(map)
                        .bindPopup(`
                            <strong>اسم السائق:</strong> ${driver.user.name}<br>
                            <strong>رقم الهاتف:</strong> ${driver.user.phone}<br>
                            <strong>الحالة:</strong> ${statusText}
                        `);
                });

              // عرض المحال التجارية
              vendors.forEach(vendor => {
                    let lat = parseFloat(vendor.latitude);
                    let lng = parseFloat(vendor.longitude);
                    if (isNaN(lat) || isNaN(lng)) return;

                    // تحديد حالة المتجر (متاح أو غير متاح)
                    let vendorStatus = vendor.is_approved === 'yes' ? 'متاح' : 'غير متاح';
                    let vendorIcon = L.icon({
                        iconUrl: vendor.is_approved === 'yes'
                            ? 'https://cdn-icons-png.freepik.com/256/15017/15017677.png?ga=GA1.1.1293284205.1746954550&semt=ais_hybrid' // صورة إذا كان المتجر متاحًا
                            : 'https://cdn-icons-png.flaticon.com/128/10726/10726411.png', // نفس الأيقونة إذا كان غير متاح (يمكن تغيير الأيقونة حسب الحاجة)
                        iconSize: [45, 45],
                        iconAnchor: [22, 45],
                        popupAnchor: [0, -35]
                    });

                    L.marker([lat, lng], { icon: vendorIcon })
                        .addTo(map)
                        .bindPopup(`
                            <strong>اسم المتجر:</strong> ${vendor.user.name}<br>
                            <strong>رقم الهاتف:</strong> ${vendor.user.phone}<br>
                            <strong>الحالة:</strong> ${vendorStatus}<br>
                            <strong>الطلب موجود؟</strong> ${vendorStatus === 'متاح' ? 'نعم' : 'لا'}
                        `);
                });


                // إخفاء رسالة التحميل بعد الانتهاء
                loadingDiv.style.display = 'none';
            })
            .catch(error => {
                console.error("فشل تحميل البيانات:", error);
                alert("حدث خطأ أثناء تحميل البيانات من الخريطة.");
                loadingDiv.textContent = "❌ فشل تحميل البيانات.";
            });
    </script>
</body>
</html>
<?php /**PATH C:\delivery-system\resources\views/dashbord/dashbord.blade.php ENDPATH**/ ?>