<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إضافة متجر جديد</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f4f8;
            padding: 30px;
        }

        .form-box {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: auto;
        }

        h2 {
            text-align: center;
            color: #4B0082;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #4B0082;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        .alert {
            background-color: #4BB543;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<h2 style="text-align: center; color:#4B0082;">قائمة المتاجر</h2>

<table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
    <thead>
        <tr style="background-color: #eee;">
            <th style="padding: 10px; border: 1px solid #ccc;">#</th>
            <th style="padding: 10px; border: 1px solid #ccc;">اسم المتجر</th>
            <th style="padding: 10px; border: 1px solid #ccc;">معرف المتجر</th>
            <th style="padding: 10px; border: 1px solid #ccc;">الموقع</th>
            <th style="padding: 10px; border: 1px solid #ccc;">طريقة الدفع</th>
            <th style="padding: 10px; border: 1px solid #ccc;">تمت الموافقة؟</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td style="padding: 10px; border: 1px solid #ccc;"><?php echo e($vendor->id); ?></td>
                <td style="padding: 10px; border: 1px solid #ccc;"><?php echo e($vendor->store_name); ?></td>
                <td style="padding: 10px; border: 1px solid #ccc;"><?php echo e($vendor->store_request_id); ?></td>
                <td style="padding: 10px; border: 1px solid #ccc;"><?php echo e($vendor->latitude); ?>, <?php echo e($vendor->longitude); ?></td>
                <td style="padding: 10px; border: 1px solid #ccc;"><?php echo e($vendor->payment_method ?? '---'); ?></td>
                <td style="padding: 10px; border: 1px solid #ccc;">
                    <?php echo e($vendor->is_approved ? 'نعم' : 'لا'); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" style="padding: 10px; border: 1px solid #ccc; text-align:center;">لا توجد متاجر حالياً.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<hr>
<div class="form-box">
    <h2>إضافة متجر جديد</h2>

    <?php if($userId): ?>
    <p>معرف المستخدم المرتبط: <?php echo e($userId); ?></p>
<?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('vendors.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>اسم المتجر:</label>
        <input type="text" name="store_name"  value="<?php echo e($storeRequest->store_name ?? ''); ?>" required>

        <label>خط العرض:</label>
        <input type="number" step="any" name="latitude" value="<?php echo e($storeRequest->longitude ?? ''); ?>" required>

        <label>خط الطول:</label>
        <input type="number" step="any" name="longitude"  value="<?php echo e($storeRequest->latitude?? ''); ?>" required>

        <label>معرف المستخدم (user_id):</label>

        <input type="number" name="user_id"  value="<?php echo e($userId ?? ''); ?>"          required>
        <label> معرف الطلبات (store_request_id):</label>
        <input type="number" name="store_request_id"  value="<?php echo e($storeRequest->id ?? ''); ?>" required>

        <label>الموقع (نص اختياري):</label>
        <input type="text" name="location">

        <label>طريقة الدفع</label>
        <select name="payment_method">
            <option value="cash" <?php echo e(($storeRequest->payment_method ?? '') == 'cash' ? 'selected' : ''); ?>>نقداً</option>
            <option value="card" <?php echo e(($storeRequest->payment_method ?? '') == 'card' ? 'selected' : ''); ?>>بطاقة</option>
        </select>
        <label>موافقة:</label>
        <select name="is_approved">
            <option value="1">نعم</option>
            <option value="0">لا</option>
        </select>

        <button type="submit">حفظ</button>
    </form>
</div>
<hr style="margin: 40px 0;">


</body>
</html>
<?php /**PATH /home/u678210090/domains/privateapp.online/laravel2/resources/views/Addnewvender.blade.php ENDPATH**/ ?>