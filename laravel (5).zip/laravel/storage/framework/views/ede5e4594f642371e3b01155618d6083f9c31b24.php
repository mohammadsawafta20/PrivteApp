<?php $__env->startSection('title', 'إدارة المستخدمين'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">إدارة المستخدمين</h2>
<a href="<?php echo e(route('users.search')); ?>" class="btn btn-info mb-3">🔍 بحث متقدم</a>

<form method="GET" action="#" class="row g-3 mb-4">
    <div class="col-md-4">
        <input type="text" name="phone" placeholder="رقم الجوال" value="<?php echo e(request('phone')); ?>" class="form-control">
    </div>
    <div class="col-md-4">
        <select name="role" class="form-control">
            <option value="">كل الأدوار</option>
            <option value="vendor" <?php echo e(request('role') == 'vendor' ? 'selected' : ''); ?>>تاجر</option>
            <option value="driver" <?php echo e(request('role') == 'driver' ? 'selected' : ''); ?>>سائق</option>
            <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>>مدير</option>
        </select>
    </div>
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">بحث</button>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success">إضافة مستخدم</a>
    </div>
</form>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>الاسم</th>
            <th>البريد</th>
            <th>الجوال</th>
            <th>الدور</th>
            <th>الرصيد</th>
            <th>موافقة</th>
            <th>آخر دخول</th>
            <th>الإجراءات</th>
        </tr>
    </thead>
    <tbody>


        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->phone); ?></td>
            <td><?php echo e($user->role); ?></td>

            <td><?php echo e($user->wallet_balance); ?></td>
            <td><?php echo e($user->is_approved ? '✅' : '❌'); ?></td>
            <td><?php echo e($user->last_login_at); ?></td>
            <td>
                <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-sm btn-warning">تعديل</a>
                <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display:inline-block">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')">حذف</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<?php echo e($users->appends(request()->query())->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder\laravel2\resources\views/users/admins/index.blade.php ENDPATH**/ ?>