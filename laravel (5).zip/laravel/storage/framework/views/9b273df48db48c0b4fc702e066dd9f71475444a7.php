<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إرسال طلب جديد</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        /* التصميم العام */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f4f8;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #4B0082;
            color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .container {
            padding: 30px;
        }

        .form-box {

            background-color: white;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 400px;
            margin: 0 auto;
        }

        .form-box input, .form-box textarea, .form-box select, .form-box button {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
        }

        .form-box button {
            background-color: #4B0082;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-box button:hover {
            background-color: #6A0DAD;
        }

        /* التنبيه */
        #successMessage {
            background-color: #4BB543;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: none;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">  اضافة سائق جديد</div>
</header>

<div class="container">

    <!-- تنبيه عند نجاح الإرسال -->
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

    <div class="form-box">
        <h3>إرسال طلب</h3>

        <form action="<?php echo e(route('drivers.storedeivers')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div style="margin-bottom: 15px;">
                <label for="user_id" style="display: block; margin-bottom: 5px;">اسم المستخدم</label>
                <select name="user_id" id="user_id" required
                    style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    <option value="">-- اختر مستخدم --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                            <?php echo e($user->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red; margin-top: 5px;"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label for="latitude">خط العرض:</label>
            <input type="number" step="any" name="latitude" id="latitude" required>

            <label for="longitude">خط الطول:</label>
            <input type="number" step="any" name="longitude" id="longitude" required>

            <label for="status">حالة الطلب:</label>
            <select name="status" id="status" required>
                <option value="busy">مشفول </option>
                <option value="offline">لا يعمل </option>
                <option value="available"> متاح</option>

            </select>

            <button type="submit"> حفظ</button>
        </form>
    </div>
</div>

<script>
    // إخفاء التنبيه بعد 5 ثواني
    setTimeout(function() {
        var successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }, 5000);
</script>

</body>
</html>
<?php /**PATH C:\delivery-system\resources\views/AddDriver.blade.php ENDPATH**/ ?>