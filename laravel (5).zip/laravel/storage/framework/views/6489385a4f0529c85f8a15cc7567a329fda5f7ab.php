

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>✏️ تعديل اسم المنطقة</h2>

    <form method="POST" action="<?php echo e(route('areas.update', $area->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name">اسم المنطقة:</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name', $area->name)); ?>" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">💾 حفظ</button>
        <a href="<?php echo e(route('areas.index')); ?>" class="btn btn-secondary">↩️ رجوع</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/Editearea.blade.php ENDPATH**/ ?>