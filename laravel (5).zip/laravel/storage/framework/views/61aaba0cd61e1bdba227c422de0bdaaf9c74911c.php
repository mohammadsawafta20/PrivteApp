

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>📋 قائمة الفروع</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('subareas.create')); ?>" class="btn btn-success mb-3">➕ إضافة فرع جديد</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>اسم الفرع</th>
                <th>سعر التوصيل </th>
                <th>تحكم</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sub->name); ?></td>
                    <td><?php echo e($sub->delivery_price); ?></td>
                    <td>
                        <a href="<?php echo e(route('subareas.edit', $sub->id)); ?>" class="btn btn-sm btn-primary">✏️ تعديل</a>

                        <form action="<?php echo e(route('subareas.destroy', $sub->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('هل تريد حذف هذا الفرع؟')">🗑️ حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/subareasshow.blade.php ENDPATH**/ ?>