


<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>✏️ تعديل الفرع: <?php echo e($subarea->name); ?></h2>

    <form method="POST" action="<?php echo e(route('subareas.update', $subarea->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">اسم الفرع:</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name', $subarea->name)); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="area_id" class="form-label">المنطقة الرئيسية:</label>
            <select name="area_id" id="area_id" class="form-control" required>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->id); ?>" <?php echo e($area->id == $subarea->area_id ? 'selected' : ''); ?>>
                        <?php echo e($area->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="delivery_price" class="form-label">سعر التوصيل:</label>
            <input type="number" name="delivery_price" id="delivery_price" value="<?php echo e(old('delivery_price', $subarea->delivery_price)); ?>" class="form-control" step="0.01" min="0" required>
        </div>

        <button type="submit" class="btn btn-primary">💾 حفظ التعديلات</button>
        <a href="<?php echo e(route('areas.index')); ?>" class="btn btn-secondary">↩️ رجوع</a>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/editesub.blade.php ENDPATH**/ ?>