

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('subareas.store')); ?>">
    <?php echo csrf_field(); ?>
    <label>الفرع:</label>
    <input type="text" name="name" class="form-control" required>

    <label>الموقع الرئيسي:</label>
    <select name="area_id" class="form-control" required>
        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>السعر:</label>
    <input type="number" name="delivery_price" class="form-control" step="0.01" min="0" placeholder="أدخل السعر" >

    <button type="submit" class="btn btn-success mt-2">حفظ</button>
</form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/subareascreate.blade.php ENDPATH**/ ?>