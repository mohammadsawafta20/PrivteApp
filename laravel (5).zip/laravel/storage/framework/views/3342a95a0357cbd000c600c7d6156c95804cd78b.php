<!-- resources/views/layouts/driver.blade.php -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'لوحة السائق'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <style>
        /* ... [نفس CSS الموجود في الكود السابق] ... */
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<header>
    <div class="menu-icon" onclick="toggleSidebar()">☰</div>
    <div id="sidebar" class="sidebar">
        <a href="/contact">التواصل مع الدعم</a>
        <div class="profile-image">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMPiZw9s7cz-zlkqLs7mv1p_4GGKFDmMmUDpOD0z2Ak5L8JHQvgv6rlwYLCq_v_ROJ1e4&usqp=CAU" alt="صورة المستخدم">
            <p class="username">اسم المستخدم</p>
        </div>
        <a href="/ProfilePage">الملف الشخصي</a>
        <a href="/driver/info">المحفظه</a>
        <a href="/orders">طلباتي</a>
        <a href="/userpage">طلب جديد</a>
        <br>
        <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                <span>تسجيل الخروج</span>
            </button>
        </form>
    </div>
    <div id="sidebarOverlay" class="sidebar-overlay" onclick="toggleSidebar()"></div>
    <nav>
        <div style="display: flex; align-items: center; gap: 25px; font-family: 'Tajawal', sans-serif; background: #f5f5f7; padding: 12px 20px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); color: #4A4A4A; max-width: 600px;">
            <?php if(session('user_name')): ?>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 48px; height: 48px; background: #6a3093; color: white; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: 700; font-size: 1.2rem; text-transform: uppercase; box-shadow: 0 2px 6px rgba(106,48,147,0.5); user-select: none;">
                        <?php echo e(substr(session('user_name'), 0, 1)); ?>

                    </div>
                    <span style="font-weight: 700; font-size: 1.1rem; white-space: nowrap;">مرحبًا، <?php echo e(session('user_name')); ?></span>
                </div>
            <?php endif; ?>
            <span style="white-space: nowrap; font-size: 1rem;">
                <strong>رقم الهاتف:</strong> <?php echo e(session('phone')); ?>

            </span>
            <span style="white-space: nowrap; font-size: 1rem;">
                <strong>المهنة:</strong>
                <?php if(session('role') === 'vendor'): ?>
                    مدير متجر
                <?php elseif(session('role') === 'driver'): ?>
                    السائق
                <?php elseif(session('role') === 'admin'): ?>
                    المشرف
                <?php else: ?>
                    <?php echo e(session('role')); ?>

                <?php endif; ?>
            </span>
        </div>
    </nav>
</header>
<main class="container">
    <?php echo $__env->yieldContent('content'); ?>
</main>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/u678210090/domains/privateapp.online/laravel/laravel/resources/views/layouts/vendor.blade.php ENDPATH**/ ?>