
        
<!DOCTYPE html>
<html lang="ar">
    <head>
        <meta charset="UTF-8">
        <title>متجر توصيل الطلبات </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Leaflet CSS -->
        <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            header {
                background-color: #4B0082	;
                color: white;
                padding: 15px 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
            }

            .logo {
                font-size: 20px;
                font-weight: bold;
            }

            nav a {
                color: white;
                text-decoration: none;
                margin: 0 10px;
                font-weight: 500;
            }

            nav a:hover {
                text-decoration: underline;
            }

            .counters {
                margin-top: 10px;
                font-size: 14px;
            }

            h1 {
                text-align: center;
                margin: 20px 0;
            }

            #order-map {
                width: 100%;
                height: 600px;
            }

            #loading {
                position: fixed;
                top: 80px;
                left: 50%;
                transform: translateX(-50%);
                background-color: #ffffff;
                border: 1px solid #ccc;
                padding: 10px 20px;
                font-weight: bold;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .stats {
                display: flex;
                gap: 15px;
                font-size: 14px;
            }

            .stats span {
                background: rgba(255, 255, 255, 0.2);
                padding: 5px 10px;
                border-radius: 10px;
            }
        </style>
    </head>
    <body>

        <!-- ✅ الهيدر مع عدادات -->
        <header>
            <div class="logo">موقع لتوصيل الطلبات</div>
            <nav>
                  <a href="/requests">الرئيسية</a>
                <a href="/orders">الطلبات</a>
                <a href="/userpage">أرسل طلب الأن</a>
                <a href="/admin/vendors/create">المستخدمين</a>
              
            </nav>
            <div class="stats">
                <span id="driver-count">السائقين: 0</span>
                <span id="vendor-count">المتاجر: 0</span>
            </div>
        </header>

<body>


    <div id="loading">🔄 جاري تحميل الخريطة...</div>

    <div id="order-map" style="width: 100%; height: 700px;"></div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        const loadingDiv = document.getElementById('loading');
        const driverCount = document.getElementById('driver-count');
        const vendorCount = document.getElementById('vendor-count');

        fetch('https://privateapp.online/api/map/data')
            .then(response => response.json())
            .then(data => {
                const drivers = data.drivers || [];
                const vendors = data.vendors || [];

                driverCount.textContent = `السائقين: ${drivers.length}`;
                vendorCount.textContent = `المتاجر: ${vendors.length}`;

                const map = L.map('order-map').setView([31.963158, 35.930359], 13);

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors'
                }).addTo(map);

                // عرض السائقين
                drivers.forEach(driver => {
                    let lat = parseFloat(driver.latitude) || 0;
                    let lng = parseFloat(driver.longitude) || 0;


                    let statusText = driver.status === 'available' ? 'متاح' : 'غير متاح';

                    let driverIcon = L.icon({
                        iconUrl: driver.status === 'available'
                            ? 'https://cdn-icons-png.freepik.com/256/2401/2401174.png?ga=GA1.1.1293284205.1746954550&semt=ais_hybrid'
                            : 'https://cdn-icons-png.flaticon.com/128/7730/7730531.png',
                        iconSize: [50, 50],
                        iconAnchor: [15, 30],
                        popupAnchor: [0, -30]
                    });

                    L.marker([lat, lng], { icon: driverIcon })
                        .addTo(map)
                        .bindPopup(`
                            <strong>اسم السائق:</strong> ${driver.user.name}<br>
                            <strong>رقم الهاتف:</strong> ${driver.user.phone}<br>
                            <strong>الحالة:</strong> ${statusText}
                        `);
                });

              // عرض المحال التجارية
              vendors.forEach(vendor => {
                    let lat = parseFloat(vendor.latitude);
                    let lng = parseFloat(vendor.longitude);
                    if (isNaN(lat) || isNaN(lng)) return;

                    // تحديد حالة المتجر (متاح أو غير متاح)
                    let vendorStatus = vendor.is_approved === 'yes' ? 'متاح' : 'غير متاح';
                    let vendorIcon = L.icon({
                        iconUrl: vendor.is_approved === 'yes'
                            ? 'https://cdn-icons-png.freepik.com/256/15017/15017677.png?ga=GA1.1.1293284205.1746954550&semt=ais_hybrid' // صورة إذا كان المتجر متاحًا
                            : 'https://cdn-icons-png.flaticon.com/128/10726/10726411.png', // نفس الأيقونة إذا كان غير متاح (يمكن تغيير الأيقونة حسب الحاجة)
                        iconSize: [45, 45],
                        iconAnchor: [22, 45],
                        popupAnchor: [0, -35]
                    });

                    L.marker([lat, lng], { icon: vendorIcon })
                        .addTo(map)
                        .bindPopup(`
                            <strong>اسم المتجر:</strong> ${vendor.user.name}<br>
                            <strong>رقم الهاتف:</strong> ${vendor.user.phone}<br>
                            <strong>الحالة:</strong> ${vendorStatus}<br>
                            <strong>الطلب موجود؟</strong> ${vendorStatus === 'متاح' ? 'نعم' : 'لا'}
                        `);
                });


                // إخفاء رسالة التحميل بعد الانتهاء
                loadingDiv.style.display = 'none';
            })
            .catch(error => {
                console.error("فشل تحميل البيانات:", error);
                alert("حدث خطأ أثناء تحميل البيانات من الخريطة.");
                loadingDiv.textContent = "❌ فشل تحميل البيانات.";
            });
    </script>
    <footer style="
    background: linear-gradient(135deg, #6e48aa 0%, #9d50bb 100%);
    color: white;
    padding: 30px 0;
    text-align: center;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    box-shadow: 0 -5px 20px rgba(0,0,0,0.1);
    margin-top: 10px;
">
    <div class="container" style="
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    ">
        <!-- حقوق النشر مع تاريخ ديناميكي -->
        <div class="copyright" style="
            margin-bottom: 15px;
            font-size: 16px;
        ">
            © <span id="current-year"></span> 
            جميع الحقوق محفوظة لـ 
            <span style="font-weight: 600;">متجر توصيل الطلبات</span>
        </div>
        
        <!-- روابط إضافية -->
        <div class="footer-links" style="
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        ">
            <a href="/privacy" style="color: white; text-decoration: none;">سياسة الخصوصية</a>
            <a href="/terms" style="color: white; text-decoration: none;">الشروط والأحكام</a>
            <a href="/contact" style="color: white; text-decoration: none;">اتصل بنا</a>
            <a href="/about" style="color: white; text-decoration: none;">عن المتجر</a>
        </div>
        
        <!-- أيقونات التواصل الاجتماعي -->
        <div class="social-icons" style="
            display: flex;
            justify-content: center;
            gap: 15px;
        ">
            <a href="#" style="color: white; font-size: 20px;">
                <i class="fab fa-facebook"></i>
            </a>
            <a href="#" style="color: white; font-size: 20px;">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="#" style="color: white; font-size: 20px;">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="#" style="color: white; font-size: 20px;">
                <i class="fab fa-whatsapp"></i>
            </a>
        </div>
    </div>

    <!-- سكريبت لعرض السنة الحالية -->
    <script>
        document.getElementById('current-year').textContent = new Date().getFullYear();
    </script>
    
    <!-- روابط Font Awesome للأيقونات -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</footer>
</body>
</html>
          <?php /**PATH /home/u678210090/domains/privateapp.online/laravel2/resources/views/dashbord/dashbord.blade.php ENDPATH**/ ?>