<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>طلبات المتاجر</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .centered-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fffae6;
            color: #333;
            border: 2px solid #ffcc00;
            padding: 30px 40px;
            border-radius: 12px;
            z-index: 9999;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.5s ease-in-out;
            text-align: center;
        }

        .alert-content .icon {
            font-size: 40px;
            margin-bottom: 10px;
            display: block;
            animation: pulse 1.2s infinite;
        }
        .logout-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    background-color: red;
    color: white;
    border: none;
    width:100px;
    margin-right:  50px;
    border-radius: 8px;
    font-size: 15px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.logout-btn:hover {
    background-color: green;
}

.logout-btn i {
    font-size: 10px;
}

/* القائمة الجانبية */
.menu-icon {
    font-size: 30px;
    cursor: pointer;
    padding: 20px;
    position: fixed;
    left: 10px;
    top: 8px;
    z-index: 1001;
    color: white;
}

.sidebar {
    height: 100%;
    width: 0;
    position: fixed;
    left: 0;
    top: 0;
    background-color: #333;
    overflow-x: hidden;
    transition: 0.3s;
    padding-top: 60px;
    z-index: 1000;
}

.sidebar a {
    padding: 15px 25px;
    text-decoration: none;
    font-size: 18px;
    color: white;
    display: block;
    transition: 0.3s;
}

.sidebar a:hover {
    background-color: #575757;
}

.sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    background: rgba(0, 0, 0, 0.4);
    transition: 0.3s;
    z-index: 999;
}

        .close-btn {
            background-color: #ffcc00;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .close-btn:hover {
            background-color: #e6b800;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -60%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.15); }
            100% { transform: scale(1); }
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f4f8;
        }

        header {
            background-color: #4B0082;
            color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav a {
            margin: 50px;
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }

        .container {
            padding: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        th {
            background-color: #eee;
            font-weight: bold;
        }

        a.button,
        button.button {
            padding: 6px 12px;
            background-color: #4B0082;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
        }

        button.button {
            border: none;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
        }

        select, button {
            padding: 8px;
            margin-top: 10px;
            width: 80%;
        }

        .close {
            float: left;
            font-size: 20px;
            color: #999;
            cursor: pointer;
        }

        .close:hover {
            color: red;
        }
    </style>

</head>
<body>

<header>
<!-- زر القائمة -->
<div class="menu-icon" onclick="toggleSidebar()">☰</div>

<!-- القائمة الجانبية -->
<div id="sidebar" class="sidebar">
      <div class="profile-image">
        <img style="width:100PX;height:100PX;" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMPiZw9s7cz-zlkqLs7mv1p_4GGKFDmMmUDpOD0z2Ak5L8JHQvgv6rlwYLCq_v_ROJ1e4&usqp=CAU" alt="صورة المستخدم">
        <p style="padding:20px;" class="username"> <?php echo e(session('user_name')); ?></p>
    </div>
    <a href="#">التواصل مع الدعم</a>

    <a href="/ProfilePage">الملف الشخصي</a>
    <a href="/users">ادارة المستخدمين</a>
       <a href="/development"> الصيانة</a>
        <a href="/dashboard">الخريطة</a>
        <a href="/admin/vendors/create">المتاجر</a>
         <a href="/orders">الطلبات المرسلة </a>
          <a href="/drivers/create"> السائقين  </a>

    <br>
         <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
        <?php echo csrf_field(); ?>
        <button type="submit" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            <span>تسجيل الخروج</span>
        </button>
    </form>
</div>

<!-- خلفية شفافة -->
<div id="sidebarOverlay" class="sidebar-overlay" onclick="toggleSidebar()"></div>




                <div style="display: flex; align-items: center; gap: 25px; font-family: 'Tajawal', sans-serif; background: #f5f5f7; padding: 12px 50px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); color: #4A4A4A; max-width: 600px;">

    <?php if(session('user_name')): ?>
        <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 48px; height: 48px; background: #6a3093; color: white; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: 700; font-size: 1.2rem; text-transform: uppercase; box-shadow: 0 2px 6px rgba(106,48,147,0.5); user-select: none;">
                <?php echo e(substr(session('user_name'), 0, 1)); ?>

            </div>
            <span style="font-weight: 700; font-size: 1.1rem; white-space: nowrap;">مرحبًا، <?php echo e(session('user_name')); ?></span>
        </div>
    <?php endif; ?>

    <span style="white-space: nowrap; font-size: 1rem;">
        <strong>رقم الهاتف:</strong> <?php echo e(session('phone')); ?>

    </span>

    <span style="white-space: nowrap; font-size: 1rem;">
        <strong>المهنة:</strong>
        <?php if(session('role') === 'admin'): ?>
            المسؤول
        <?php else: ?>
            <?php echo e(session('role')); ?>

        <?php endif; ?>
    </span>

  <div>

  </div>
<div>

</div>



</header>
<div class="container" >


    <?php if(session('newRequest')): ?>
    <div id="newRequestAlert" class="centered-alert">
        <div class="alert-content">
            <span class="icon">🔔</span>
            <p><strong>تنبيه:</strong> هناك طلب جديد تم إرساله!</p>
            <button onclick="closeAlert()" class="close-btn">إغلاق</button>
        </div>
    </div>

    <audio id="notificationSound" autoplay>
        <source src="https://www.soundjay.com/buttons/sounds/beep-07.mp3" type="audio/mpeg">
    </audio>

    <script>
        window.addEventListener('DOMContentLoaded', function () {
            const sound = document.getElementById('notificationSound');
            if (sound) sound.play().catch(() => {});
        });

        function closeAlert() {
            document.getElementById('newRequestAlert')?.remove();
        }

        setTimeout(() => {
            closeAlert();
        }, 10000);
    </script>

    <?php session()->forget('newRequest'); ?>
<?php endif; ?>


    <div class="stat-box">
        <h3> عدد الطلبات المرسله </h3>
        <p><?php echo e($ordersCount); ?></p>
    </div>
    <div class="stat-box">
        <h3>عدد السائقين المتاحين</h3>
        <p><?php echo e($availableDriversCount); ?></p>
    </div>

    <h2>طلبات المتاجر</h2>

    <table>
        <tr>
            <th>المتجر</th>
            <th>التفاصيل</th>
            <th>الموقع</th>
            <th>إجراء</th>
        </tr>
        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($req->store_name); ?></td>
                <td><?php echo e($req->status); ?></td>
                <td><?php echo e($req->latitude); ?>,<?php echo e($req->longitude); ?></td>
                <td>
                    <a class="button" onclick="openModal(<?php echo e($req->id); ?>, '<?php echo e($req->store_name); ?>')">تحديد سائق</a>
                    <a href="<?php echo e(route('Addnewvender', ['request_id' => $req->id])); ?>" class="button">حفظ</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<!-- نافذة منبثقة لاختيار السائق -->
<div id="driverModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">×</span>
        <h3>اختيار سائق للمتجر: <span id="storeName"></span></h3>
        <form method="POST" action="<?php echo e(route('dashbord.assign.driver')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="vendor_id" id="storeId">
            <label for="driver_id">اختر السائق:</label><br>
            <select name="driver_id" required>
                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            <button type="submit">حفظ الطلب</button>
        </form>
    </div>
</div>

<script>
    function openModal(storeId, storeName) {
        document.getElementById('driverModal').style.display = 'block';
        document.getElementById('storeId').value = storeId;
        document.getElementById('storeName').textContent = storeName;
    }

    function closeModal() {
        document.getElementById('driverModal').style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target === document.getElementById('driverModal')) {
            closeModal();
        }
    };
</script>
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (sidebar.style.width === '250px') {
            sidebar.style.width = '0';
            overlay.style.width = '0';
        } else {
            sidebar.style.width = '250px';
            overlay.style.width = '100%';
        }
    }
</script>

</body>
</html>
<?php /**PATH /home/u678210090/domains/privateapp.online/laravel/resources/views/dashbord/Adminpage.blade.php ENDPATH**/ ?>