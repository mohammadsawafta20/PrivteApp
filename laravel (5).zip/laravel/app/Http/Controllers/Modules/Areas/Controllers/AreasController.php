<?php

namespace App\Http\Controllers\Modules\Areas\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AreasController extends Controller
{
    //
}
