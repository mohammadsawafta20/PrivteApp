<?php

namespace App\Http\Controllers\Modules\Users\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DriverController extends Controller
{
    //
}
