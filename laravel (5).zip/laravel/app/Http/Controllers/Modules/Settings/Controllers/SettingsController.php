<?php

namespace App\Http\Controllers\Modules\Settings\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    //
}
